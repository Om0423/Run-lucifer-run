var path
var jake

function preload(){
 pathImg = loadImage("path.png");
 jakeImg= loadImage("Jake1.png","Jake2.png","jake3.png","jake4.png","jake5.png");
 
  
}

function setup(){
  createCanvas(400,400);
  path = createSprite(200,200);
  path.addImage(pathImg)
  path.velocityY = 4;
  path.scale=1.2;
  jake = createSprite (200,200);
  jake.addImage(jakeImg);

  
}

function draw() {
  background(0);
 drawSprites();
}
